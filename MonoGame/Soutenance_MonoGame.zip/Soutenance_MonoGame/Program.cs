﻿
using var game = new Soutenance_MonoGame.MainGame();
game.Run();
