local _Entity = require("entities/_Entity");
local Projectile = require("entities/projectiles/Projectile");
local HeroChargeFX = require("entities/FXs/HeroCharge");
local HeroChargeReadyFX = require("entities/FXs/HeroChargeReady");
local Anim = require("constructors/Anim");

local Bow = {};
setmetatable(Bow, {__index = _Entity});

function Bow:New(x, y)
    local tmpWeapon = _Entity:New("Weapon", "player");
    --print("Création d'une instance de "..tmpWeapon.name);
    setmetatable(tmpWeapon, {__index = Bow});

    -- Inner
    tmpWeapon.position = Vector.New(x, y);
    tmpWeapon.size = Vector.New(48, 48);
    tmpWeapon.pivot = Vector.New(tmpWeapon.size.x * 0.5, tmpWeapon.size.y * 0.5);
    
    -- Behaviour
    tmpWeapon.states["idle"] = 0;
    tmpWeapon.states["charge"] = 1;
    tmpWeapon.states["shoot"] = 2;
    tmpWeapon.states["reload"] = 3;

    tmpWeapon.chargeTimer = 0.4;
    tmpWeapon.chargeCurrentTimer = tmpWeapon.chargeTimer;

    tmpWeapon.damages = 1;
    tmpWeapon.arrowsUpgraded = false;

    tmpWeapon.reloadSpeed = 0.5;
    tmpWeapon.currentReloadTimer = tmpWeapon.reloadSpeed;

    -- Graph
    tmpWeapon.spritesheet = love.graphics.newImage("images/player/bow.png");
    tmpWeapon.anims = tmpWeapon:PopulateAnims();
    tmpWeapon.renderLayer = 7;

    tmpWeapon.chargeFX = HeroChargeFX:New(hero.position);
    tmpWeapon.chargeReadyFX = HeroChargeReadyFX:New(hero.position);

    table.insert(entities, tmpWeapon);

    return tmpWeapon;
end

function Bow:Update(dt)
    -- Weapon Controls
    self.position = Vector.New(hero.position.x, hero.position.y)

    if GetMousePos().y + cameraOffset.y > hero.position.y then
        self:ChangeRenderLayer(9);
    else
        self:ChangeRenderLayer(7);
    end

        -- Weapon states machine
    if love.mouse.isDown(1) then
        if self.state == 0 then
            self:ChangeState("charge");
        elseif self.state == 1 then
            self.canShoot = self:CanShoot(dt);
            self:EnableChargeFX(dt);
            if self.canShoot then
                self:EnableChargeReadyFX(dt);
            end
        elseif self.state == 2 then
            if self:IsWaiting(dt, 0.2) then
                self:ChangeState("reload");
            end
        elseif self.state == 3 then
            self.canReload = self:CanReload(dt);
            if self.canReload then
                self:ChangeState("idle");
            end
        end
    else
        if self.state == 1 and self.canShoot then
            self:ResetChargeTimer();
            Projectile:NewArrow(self.position.x, self.position.y, self.damages, self.arrowsUpgraded);
            self:ChangeState("shoot");
            self:DisableChargeFX();
            self:DisableChargeReadyFX();
        elseif self.state == 1 and self.canShoot == false then
            self:ResetChargeTimer();
            self:ChangeState("idle");
            self:DisableChargeFX();
            self:DisableChargeReadyFX();
        elseif self.state == 2 then
            if self:IsWaiting(dt, 0.2) then
                self:ChangeState("reload");
            end
        elseif self.state == 3 then
            self.canReload = self:CanReload(dt);
            if self.canReload then
                self:ChangeState("idle");
            end
        end
    end 

    -- Animations
    self:UpdateAnim(dt, self.anims[self.state][0]);
end

function Bow:Draw()
    local angle;
    if isUpgrading == false then
        local delta = GetMousePos() - self.position + cameraOffset;
        angle = delta:GetAngle() - math.pi*0.5;
        love.graphics.draw(
            self.spritesheet,
            self:GetCurrentQuadToDisplay(self.anims[self.state][0]),
            self.position.x,
            self.position.y,
            angle,
            self.scale.x,
            self.scale.y,
            self.pivot.x,
            self.pivot.y
        );
    else
        love.graphics.draw(
            self.spritesheet,
            self:GetCurrentQuadToDisplay(self.anims[self.state][0]),
            self.position.x,
            self.position.y,
            angle,
            self.scale.x,
            self.scale.y,
            self.pivot.x,
            self.pivot.y
        );
    end
end

function Bow:EnableChargeReadyFX(dt)
    self.chargeReadyFX.active = true;
    self.chargeReadyFX:UpdateAnim(dt, self.chargeReadyFX.anims[self.chargeReadyFX.state][0]);
end

function Bow:DisableChargeReadyFX()
    self.chargeReadyFX.active = false;
    self.chargeReadyFX:ResetAnim(self.chargeReadyFX.anims[self.chargeReadyFX.state][0]);
end

function Bow:EnableChargeFX(dt)
    self.chargeFX.active = true;
    self.chargeFX:UpdateAnim(dt, self.chargeFX.anims[self.chargeFX.state][0]);
end

function Bow:DisableChargeFX()
    self.chargeFX.active = false;
    self.chargeFX:ResetAnim(self.chargeFX.anims[self.chargeFX.state][0]);
end

function Bow:CanShoot(dt)
    if self.chargeCurrentTimer > 0 then
        self.chargeCurrentTimer = self.chargeCurrentTimer - dt;
    end
    return self.chargeCurrentTimer <= 0;
end

function Bow:ResetChargeTimer()
    self.chargeCurrentTimer = self.chargeTimer;
end

function Bow:PopulateAnims()
    local anims = {};
    local idleAnims = {};
    local chargeAnims = {};
    local shootAnims = {};
    local reloadAnims = {};
    anims[0] = idleAnims;
    anims[1] = chargeAnims;
    anims[2] = shootAnims;
    anims[3] = reloadAnims;

    local idleAnim = Anim:New(self.size.x, self.size.y, 0, 0, 1, true);
    local chargeAnim = Anim:New(self.size.x, self.size.y, 1, 3, self.chargeTimer, false);
    local shootAnim = Anim:New(self.size.x, self.size.y, 4, 4, 2, false);
    local reloadAnim = Anim:New(self.size.x, self.size.y, 5, 5, self.reloadSpeed, false);
    anims[0][0] = idleAnim;
    anims[1][0] = chargeAnim;
    anims[2][0] = shootAnim;
    anims[3][0] = reloadAnim;

    return anims;
end

return Bow;